const e=""+new URL("empty-image-default-ZSii6XPz.png",import.meta.url).href;export{e as _};
